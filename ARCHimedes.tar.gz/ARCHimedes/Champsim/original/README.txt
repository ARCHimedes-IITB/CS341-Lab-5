This contains the original versions of the modified files.
